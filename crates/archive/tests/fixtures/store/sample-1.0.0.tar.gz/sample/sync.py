print("{}")
